import React from 'react';

const GameInstructions = () => {
  return (
    <div className="modal">
      <h3>How to Play</h3>
      <p>Click on objects in each room to solve puzzles and discover treasures!</p>
    </div>
  );
};

export default GameInstructions;
