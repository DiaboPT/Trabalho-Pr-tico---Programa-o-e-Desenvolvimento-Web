import React from 'react';

const Scoreboard = ({ score }) => {
  return (
    <div style={{ position: 'absolute', top: '10px', right: '10px' }}>
      <h3>Score: {score}</h3>
    </div>
  );
};

export default Scoreboard;
