import React, { useState, useEffect } from "react";

const Ranking = ({ score }) => {
  const [ranking, setRanking] = useState([]);

  useEffect(() => {
    const storedRanking = JSON.parse(localStorage.getItem("ranking")) || [];
    console.log("Loaded ranking from localStorage:", storedRanking); // Debug
    setRanking(storedRanking);
  }, []);
  

  const addScoreToRanking = (newScore) => {
    if (newScore <= 0) return;

    const storedRanking = (() => {
      try {
        return JSON.parse(localStorage.getItem("ranking")) || [];
      } catch {
        return [];
      }
    })();
    

    // Avoid adding duplicate scores
    if (storedRanking.some((entry) => entry.score === newScore)) return;

    const newRanking = [
      ...storedRanking,
      { score: newScore, date: new Date().toLocaleString() },
    ];

    // Sort by score in descending order
    newRanking.sort((a, b) => b.score - a.score);

    setRanking(newRanking);
    localStorage.setItem("ranking", JSON.stringify(newRanking));
    console.log("Updated ranking:", newRanking); // Debugging
  };

  useEffect(() => {
    if (score > 0) {
      addScoreToRanking(score);
    }
  }, [score]);

  return (
    <div className="ranking">
      <h3>Ranking</h3>
      {ranking.length === 0 ? (
        <p>No scores yet.</p>
      ) : (
        <ul>
          {ranking.map((entry, index) => (
            <li key={index}>
              {index + 1}. {entry.score} - {entry.date}
            </li>
          ))}
        </ul>
      )}
    </div>
    
  );
  
};

export default Ranking;
