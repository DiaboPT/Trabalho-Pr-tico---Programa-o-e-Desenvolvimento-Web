// In TreasureRoom.js
import React, { useState } from 'react';

const TreasureRoom = () => {
  const [puzzleSolved, setPuzzleSolved] = useState(false);

  const solvePuzzle = () => {
    setPuzzleSolved(true);
    alert("Puzzle solved! You unlocked the treasure.");
  };

  return (
    <div>
      <h3>Welcome to the Treasure Room!</h3>
      {!puzzleSolved ? (
        <button onClick={solvePuzzle}>Solve Puzzle</button>
      ) : (
        <p>Treasure unlocked!</p>
      )}
    </div>
  );
};

export default TreasureRoom;
