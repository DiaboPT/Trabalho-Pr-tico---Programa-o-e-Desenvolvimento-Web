import React, { useState, useEffect } from "react";
import "./GameBoard.css";
import Ranking from "./Ranking";

import door_image from "./image/door.jpg";
import mdt_image from "./image/MÁSCARA_DE_TUTANCÂMON.png";

// Initial room setup with doors
const initialRooms = () => [
	{
		id: "room1",
		name: "Room 1",
		visited: true,
		objects: [
			{
				id: "door",
				x: 100,
				y: 100,
				image: door_image,
				type: "door",
				targetRoom: "room1", // Target room to switch to
			},
			{
				id: "NO HEAD?",
				x: 1000,
				y: 300,
				image: mdt_image,
				puzzle: "Qual é o simbolo do poder do egito e da vida interna?",
				answer: "MÁSCARA DE TUTANCÂMON",
				solved: false,
				item: {
					image: mdt_image,
					name: "MÁSCARA DE TUTANCÂMON",
					description: "The Egyptians made ceramic drinking vessels for their beverages, and sometimes turned them into works of art."
				}, // Item to be added to inventory
			},
			{
				id: "door",
				x: 1750,
				y: 100,
				image: door_image,
				type: "door", // Indicating it's a door
				targetRoom: "room2", // Target room to switch to
			},
		],
	},
	{
		id: "room2",
		name: "Room 2",
		visited: false,
		objects: [
			{
				id: "door",
				x: 100,
				y: 100,
				image: door_image,
				type: "door",
				targetRoom: "room1", // Target room to switch to
			},
			{
				id: "artifact",
				x: 1000,
				y: 300,
				puzzle: "1?",
				answer: "1",
				solved: false,
				item: {
					name: "artifact",
					description: "artifact"
				}, // Item to be added to inventory
			},
			{
				id: "door",
				x: 1750,
				y: 100,
				image: door_image,
				type: "door", // Indicating it's a door
				targetRoom: "room3", // Target room to switch to
			},
		],
	},
	{
		id: "room3",
		name: "Room 3",
		visited: false,
		objects: [
			{
				id: "door",
				x: 100,
				y: 100,
				image: door_image,
				type: "door", // Indicating it's a door
				targetRoom: "room2", // Target room to switch to
			},
		],
	},
];

const GameBoard = () => {
	const [playerPosition, setPlayerPosition] = useState({ x: 500, y: 500 });
	const [currentPuzzleIndex, setCurrentPuzzleIndex] = useState(null);
	const [score, setScore] = useState(0);
	const [gameOver, setGameOver] = useState(false);
	const [inputValue, setInputValue] = useState("");
	const [rooms, setRooms] = useState(initialRooms());
	const [currentRoom, setCurrentRoom] = useState("room1"); // Start in Room 1
	const [feedback, setFeedback] = useState("");
	const [visitedRooms, setVisitedRooms] = useState(["room1"]);
	const [inventory, setInventory] = useState([]); // State to store collected items
	const [isInventoryOpen, setIsInventoryOpen] = useState(false); // State to manage inventory visibility
	const [expandedItem, setExpandedItem] = useState(null); // State to track expanded item
	const [lastUsedDoor, setLastUsedDoor] = useState(null);
	const INTERACTION_THRESHOLD = 50; // Distance in pixels

	// Render map
	const renderMap = () => {
		return rooms.map((room) => (
			<div key={room.id} className="map-row">
				{visitedRooms.includes(room.id) && (room.id === currentRoom ? "8" : "0")}
			</div>
		));
	};

	// Render inventory
	const renderInventory = () => {
		return inventory.map((item, index) => (
			<div
				key={index}
				className="inventory-item"
				onClick={() => setExpandedItem(item)} // Click to expand the item
			>
				<img src={item.image} alt={item.name} className="inventory-item-image" />
			</div>
		));
	};

	const isCloseEnough = (playerPosition, objectPosition) => {
		const dx = playerPosition.x - objectPosition.x;
		const dy = playerPosition.y - objectPosition.y;
		return Math.sqrt(dx * dx + dy * dy) <= INTERACTION_THRESHOLD;
	};

	const handleObjectClick = (object) => {
		// Check if the player is close enough to interact with the object
		if (!isCloseEnough(playerPosition, { x: object.x, y: object.y })) {
			// If not, move the player closer to the object
			setPlayerPosition({ x: object.x, y: object.y });
			return; // Stop here so interaction happens only after reaching the object
		}

		// Interaction logic (only if close enough)
		if (object.type === "door") {
			setLastUsedDoor(object); // Track the door being used
			switchRoom(object.targetRoom);
		} else if (!object.solved && !gameOver) {
			setCurrentPuzzleIndex(
				rooms
					.find((room) => room.id === currentRoom)
					.objects.findIndex((obj) => obj.id === object.id)
			);
		}
	};

	const switchRoom = (targetRoom) => {
		// Add room to visited list if not already visited
		if (!visitedRooms.includes(targetRoom)) {
			setVisitedRooms([...visitedRooms, targetRoom]);
		}

		// Find the corresponding door in the target room
		const targetRoomData = rooms.find((room) => room.id === targetRoom);
		let targetDoor = { x: 500, y: 500 }; // Default position if no match

		if (lastUsedDoor) {
			const matchingDoor = targetRoomData.objects.find(
				(obj) => obj.type === "door" && obj.targetRoom === currentRoom
			);
			if (matchingDoor) {
				targetDoor = { x: matchingDoor.x, y: matchingDoor.y };
			}
		}

		// Update player position and current room
		setCurrentRoom(targetRoom);
		setPlayerPosition({ x: targetDoor.x, y: targetDoor.y });
	};


	const solvePuzzle = () => {
		const currentObject = rooms.find((room) => room.id === currentRoom).objects[currentPuzzleIndex];
		const isCorrect = currentObject.answer.toLowerCase() === inputValue.trim().toLowerCase();

		setFeedback(isCorrect ? "Correct!" : "Wrong answer.");

		if (isCorrect) {
			setScore(score + 10);

			// Add item to inventory if it exists
			if (currentObject.item) {
				setInventory([...inventory, currentObject.item]);
			}
		}

		// Update the solved status of the object
		const updatedRooms = rooms.map((room) => {
			if (room.id === currentRoom) {
				const updatedObjects = room.objects.map((object, index) => {
					if (index === currentPuzzleIndex) {
						return { ...object, solved: true };
					}
					return object;
				});
				return { ...room, objects: updatedObjects };
			}
			return room;
		});

		setRooms(updatedRooms);
		setInputValue("");
		setCurrentPuzzleIndex(null);

		// Check if all puzzles are solved in all rooms
		const allPuzzlesSolved = updatedRooms.every((room) =>
			room.objects.every((obj) => obj.solved || !obj.puzzle)
		);

		if (allPuzzlesSolved) {
			setGameOver(true); // Trigger Game Over when all puzzles are solved
		}

		setTimeout(() => setFeedback(""), 2000);
	};


	const restartGame = () => {
		setGameOver(false);
		setScore(0);
		setPlayerPosition({ x: 500, y: 500 });
		setCurrentPuzzleIndex(null);
		setInputValue("");
		setRooms(initialRooms());
		setVisitedRooms(["room1"]);
		setInventory([]); // Clear inventory
		setFeedback("");
	};

	return (
		<div className="game-board">
			{/* Feedback Message */}
			{feedback && <div className="feedback">{feedback}</div>}

			<div
				className="player"
				style={{
					position: "absolute",
					left: playerPosition.x,
					top: playerPosition.y,
				}}
			></div>


			{rooms.find((room) => room.id === currentRoom).objects.map((object) => (
				<div
					key={object.id}
					className="interactive-object"
					style={{
						left: `${object.x}px`,
						top: `${object.y}px`,
						opacity: object.solved ? 0.5 : 1,
						pointerEvents: object.solved || gameOver ? "none" : "auto",
					}}
					onClick={() => handleObjectClick(object)}
				>
					<img
						src={object.image}
						style={{
							backgroundSize: "cover",
							filter: object.solved ? "grayscale(100%)" : "none",
						}}
					/>
				</div>
			))}

			{currentPuzzleIndex !== null && !gameOver && (
				<div className="puzzle-modal">
					<p>{rooms.find((room) => room.id === currentRoom).objects[currentPuzzleIndex].puzzle}</p>
					<input
						type="text"
						value={inputValue}
						onChange={(e) => setInputValue(e.target.value)}
						placeholder="Enter your answer"
						autoFocus
					/>
					<button onClick={solvePuzzle}>Submit</button>
				</div>
			)}

			{gameOver && (
				<div className="game-over">
					<h3>Game Over!</h3>
					<p>Your Final Score: {score}</p>
					<button onClick={restartGame}>Restart Game</button>
					<Ranking />
				</div>
			)}

			<div className="map-and-score">
				{/* Score Display */}
				<div className="score-display">
					<h2>Score: {score}</h2>
				</div>

				{/* Map Window (Top-right corner) */}
				<div className="map-window">
					<h3>Map</h3>
					{renderMap()}
				</div>
			</div>

			{/* Inventory Button */}
			<button className="inventory-button" onClick={() => setIsInventoryOpen(true)}>Open Inventory</button>

			{/* Inventory Window (Full-screen) */}
			{isInventoryOpen && (
				<div className="inventory-window-fullscreen">
					<h3>Inventory</h3>
					<button className="close-inventory" onClick={() => setIsInventoryOpen(false)}>Close Inventory</button>

					{/* Inventory Grid */}
					<div className="inventory-grid">
						{renderInventory()}
					</div>

					{/* Expanded Item Details */}
					{expandedItem && (
						<div className="expanded-item-details">
							<div className="expanded-item-content">
								<img
									src={expandedItem.image}
									alt={expandedItem.name}
									className="expanded-item-image"
								/>
								<div className="expanded-item-text">
									<h4>{expandedItem.name}</h4>
									<p>{expandedItem.description}</p>
									<button onClick={() => setExpandedItem(null)}>Close</button>
								</div>
							</div>
						</div>
					)}



				</div>
			)}
		</div>
	);
};

export default GameBoard;
