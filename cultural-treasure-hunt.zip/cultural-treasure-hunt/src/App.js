import React, { useState } from 'react';
import './App.css';
import GameBoard from './components/GameBoard';
import GameInstructions from './components/GameInstructions';

function App() {
	return (
		<div className="App">
			<GameInstructions />
			<GameBoard />
		</div>
	);
}

export default App;
